#!/usr/bin/env python3
"""MutEntries (r40 w2) — mutation probe: new knowledge entries vs the trio gates.

Gates: G1 source-recheck.py, G2 recheck-audit.py, G3 frontier-recheck-count.py.
Mirror: hardlink farms of the pristine Y extraction ($S/fresh). One uniform,
documented adaptation: every corpus/knowledge/*.md recheck-line literal
`cd /home/vgpnk/Projects/shokunin/kasegi-shokunin` is rewritten to `cd <farm>`
so executed lines re-check farm bytes. Applied identically to base and mutants.
"""
import concurrent.futures as cf
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

S = "/fast/scratch/hyaku/kasegi-r40/MutEntries"
FRESH = f"{S}/fresh"
LANE = "/home/vgpnk/Projects/shokunin/kasegi-shokunin"
KP = "corpus/knowledge/"
ENTRIES = {
    "anthropic-cvd-provenance-and-pacing": "S016",
    "cisa-bod-20-01-vdp-minimums": "S021",
    "cisa-cvd-program-stages": "S023",
    "cve-bench-agent-exploitation-benchmark": "S025",
    "cyclonedx-analysis-subtree": "S060",
    "doj-vdp-framework-scope-and-authorization": "S020",
    "nist-sp800-216-vdp-framework": "S019",
    "pz-reporting-transparency-trial": "S017",
}
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def sha(b):
    return hashlib.sha256(b).hexdigest()


def pristine(name):
    with open(f"{FRESH}/{KP}{name}.md", "rb") as fh:
        return fh.read()


def adapt(text, farm):
    return text.replace(LANE + " &&", farm + " &&")


# --- mutants: return (mutated_text, exact description) -----------------------
def m1(text, name, farm):
    lines = text.split("\n")
    hits = [i for i, l in enumerate(lines) if re.match(r"^source: S\d", l)]
    assert len(hits) == 1, (name, hits)
    i = hits[0]
    desc = f"deleted line {i+1} ({len(lines[i])} chars): {lines[i][:72]!r}..."
    del lines[i]
    return "\n".join(lines), desc


def _first_quote_idx(lines):
    for i, l in enumerate(lines):
        if re.match(r'^> "', l):
            return i
    raise AssertionError("no quote line")


def m2(text, name, farm):
    lines = text.split("\n")
    i = _first_quote_idx(lines)
    m = re.match(r'^> "(.+)"(.*)$', lines[i])
    assert m, lines[i]
    q, tail = m.group(1), m.group(2)
    cut = q[: max(1, int(len(q) * 0.4))]
    new = f'> "{cut}' + tail  # closing quote dropped: truncated mid-span
    desc = f"line {i+1}: quote truncated {len(q)}->{len(cut)} chars (closing quote dropped, attribution kept)"
    lines[i] = new
    return "\n".join(lines), desc


def m3(text, name, farm):
    lines = text.split("\n")
    i = _first_quote_idx(lines)
    m = re.search(r"((?:S\d{3}\.txt:)?)L(\d+)\b", lines[i])
    assert m, lines[i]
    old = m.group(0)
    new = f"{m.group(1)}L{int(m.group(2)) + 1}"
    desc = f"line {i+1}: attribution line-anchor changed {old} -> {new}"
    lines[i] = lines[i].replace(old, new, 1)
    return "\n".join(lines), desc


def m3b(text, name, farm):
    if name != "cyclonedx-analysis-subtree":
        return None
    lines = text.split("\n")
    for i, l in enumerate(lines):
        if "6 9 5 3" in l:
            desc = f"line {i+1}: FC-3 counted enum sizes '6 9 5 3' -> '7 9 5 3'"
            lines[i] = l.replace("6 9 5 3", "7 9 5 3", 1)
            return "\n".join(lines), desc
    raise AssertionError("FC-3 count line not found")


def m4(text, name, farm):
    lines = text.split("\n")
    start = next(i for i, l in enumerate(lines) if l.startswith("## Falsifiable rule"))
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("## "):
            end = j
            break
    removed = end - start
    desc = f"deleted lines {start+1}-{end} ({removed} lines): '## Falsifiable rule' section through next '## ' heading"
    return "\n".join(lines[:start] + lines[end:]), desc


CANARY = ('credential-scan-canary: api_key = "AKIAIOSFODNN7EXAMPLE", '
          'token = "ghp_0123456789abcdef0123456789abcdef0123"\n')


def m5(text, name, farm):
    if not text.endswith("\n"):
        text += "\n"
    return text + CANARY, "appended credential-like canary line at EOF (AKIA... key id + ghp_ token)"


MUTANTS = {"M1-drop-source": m1, "M2-truncate-quote": m2, "M3-change-number": m3,
           "M3b-enum-count": m3b, "M4-drop-falsifiable": m4, "M5-credential": m5}


def build_farm(tag):
    # guard: the extraction source must still carry the unadapted lane path
    with open(f"{FRESH}/{KP}cyclonedx-analysis-subtree.md", encoding="utf-8") as fh:
        assert ("cd " + LANE + " &&") in fh.read(), "FRESH contaminated — rebuild before probing"
    farm = f"{S}/m-{tag}"
    subprocess.run(["cp", "-al", FRESH, farm], check=True)
    # uniform adaptation: rewrite the recheck-line lane path in EVERY entry.
    # unlink before write: cp -al shares inodes with FRESH, and an in-place write
    # would clobber the pristine extraction through the hardlink.
    for dirpath, _dirs, files in os.walk(os.path.join(farm, "corpus/knowledge")):
        for fn in files:
            if fn.endswith(".md"):
                p = os.path.join(dirpath, fn)
                with open(p, encoding="utf-8") as fh:
                    t = fh.read()
                a = adapt(t, farm)
                if a != t:
                    os.unlink(p)
                    with open(p, "w", encoding="utf-8") as fh:
                        fh.write(a)
    return farm


def write_entry(farm, name, content):
    p = os.path.join(farm, f"{KP}{name}.md")
    os.unlink(p)  # detach hardlink before overwrite
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(content)


def run(cmd, farm, timeout=900):
    r = subprocess.run(cmd, cwd=farm, capture_output=True, text=True, timeout=timeout, env=ENV)
    return r.returncode, r.stdout, r.stderr


def gate_paths(farm, tag):
    return [
        ("G1", ["python3", "corpus/instruments/source-recheck.py",
                "--manifest", "corpus/source-snapshots/round-40/manifest.json"], None),
        ("G2", ["python3", "corpus/instruments/recheck-audit.py", "--root", farm,
                "--quiet", "--json", f"{S}/out/{tag}-audit.json"], None),
        ("G3", ["python3", "corpus/instruments/frontier-recheck-count.py", "--root", farm], None),
    ]


def summarize(tag, farm, gname, rc, out, err):
    lines = [l for l in out.splitlines() if l.strip()]
    key = ""
    for l in lines:
        if gname == "G1" and l.startswith("manifest"):
            key = l
        if gname == "G2" and (l.startswith("lines=") or l.startswith("expect=")):
            key = (key + " | " + l).strip(" |")
        if gname == "G3" and (l.startswith("entries=") or "F23" in l or l.startswith("DUPLICATE")):
            key = (key + " | " + l).strip(" |")
    if gname == "G1":
        ok_lines = [l for l in lines if l.endswith("OK")]
        key = f"records OK={sum(1 for l in lines if ':sha256 OK' in l)} exit={rc} last={lines[-1] if lines else ''}"
    return {"tag": tag, "gate": gname, "rc": rc, "summary": key,
            "stderr_tail": err.strip().splitlines()[-1] if err.strip() else ""}


def probe(tag, farm):
    res = []
    for gname, argv, _ in gate_paths(farm, tag):
        rc, out, err = run(argv, farm)
        res.append(summarize(tag, farm, gname, rc, out, err))
    return res


def main():
    os.makedirs(f"{S}/out", exist_ok=True)
    os.makedirs(f"{S}/fixtures", exist_ok=True)
    results = []

    # B1: adapted, unmutated base farm — the comparability baseline
    base = build_farm("base")
    base_res = probe("base", base)
    results.extend(base_res)
    if any(r["rc"] != 0 for r in base_res):
        print("BASELINE RED on adapted unmutated mirror — inconclusive, aborting before mutants:")
        for r in base_res:
            print(f'  {r["gate"]} rc={r["rc"]} {r["summary"]}')
            if r["stderr_tail"]:
                print("   stderr:", r["stderr_tail"])
        with open(f"{S}/results.json", "w") as fh:
            json.dump(results, fh, indent=1)
        return 3

    # mutants
    jobs = []
    for name, sid in ENTRIES.items():
        for mtag, fn in MUTANTS.items():
            jobs.append((name, sid, mtag, fn))
    jobs = [(n, s, m, f) for (n, s, m, f) in jobs if f is not m3b or n == "cyclonedx-analysis-subtree"]

    def one(job):
        name, sid, mtag, fn = job
        tag = f"{name[:28]}__{mtag}"
        farm = build_farm(tag)
        orig = pristine(name).decode("utf-8")
        adapted = adapt(orig, farm)
        mut, desc = fn(adapted, name, farm)
        assert mut != adapted, (tag, "mutation was a no-op")
        write_entry(farm, name, mut)
        # byte-exact fixture copy
        fx = f"{S}/fixtures/{tag}.md"
        with open(fx, "w", encoding="utf-8") as fh:
            fh.write(mut)
        meta = {"tag": tag, "entry": name, "source_id": sid, "mutant": mtag,
                "description": desc,
                "sha256_pristine": sha(orig.encode("utf-8")),
                "sha256_mutant": sha(mut.encode("utf-8")),
                "fixture_sha256": None}
        meta["fixture_sha256"] = sha(open(fx, "rb").read())
        res = probe(tag, farm)
        # restoration: rewrite pristine adapted bytes, re-verify entry hash
        write_entry(farm, name, adapted)
        with open(f"{farm}/{KP}{name}.md", "rb") as fh:
            restored = fh.read()
        meta["restored_sha256_matches_adapted"] = sha(restored) == sha(adapted.encode("utf-8"))
        shutil.rmtree(farm, ignore_errors=True)
        return meta, res

    with cf.ThreadPoolExecutor(max_workers=5) as ex:
        for meta, res in ex.map(one, jobs):
            results.extend(res)
            results.append({"tag": meta["tag"], "gate": "META", "rc": 0,
                            "summary": json.dumps(meta, sort_keys=True), "stderr_tail": ""})

    with open(f"{S}/results.json", "w") as fh:
        json.dump(results, fh, indent=1)
    for r in results:
        print(f'{r["gate"]:4} {r["tag"]:60} rc={r["rc"]} {r["summary"][:150]}')


if __name__ == "__main__":
    sys.exit(main())
