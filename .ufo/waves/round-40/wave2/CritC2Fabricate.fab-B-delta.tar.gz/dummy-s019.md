source: S019 — https://csrc.nist.gov/pubs/sp/800/216/final — capture corpus/source-snapshots/round-40/S019.txt (7 lines, 514 bytes; sha256 8fc408656c5de95fdf179c6f4a1cd31f20ebe5f0730891e83a2d7a149e9455fa): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S019 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "NIST guidance asks agencies to designate a single central reporting mailbox."
