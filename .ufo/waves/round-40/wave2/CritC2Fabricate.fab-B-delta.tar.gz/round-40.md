# round-40 lesson (fabricated fixture)

## Gate

- **S021** — REJECTED: reason+flip recorded (fabricated fixture).
- **S022** — REJECTED: reason+flip recorded (fabricated fixture).
- **S023** — REJECTED: reason+flip recorded (fabricated fixture).
- **S024** — REJECTED: reason+flip recorded (fabricated fixture).
- **S025** — REJECTED: reason+flip recorded (fabricated fixture).
