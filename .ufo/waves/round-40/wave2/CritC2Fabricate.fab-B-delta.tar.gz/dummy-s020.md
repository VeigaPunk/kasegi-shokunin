source: S020 — https://www.justice.gov/criminal/criminal-ccips/page/file/983996/dl?inline= — capture corpus/source-snapshots/round-40/S020.txt (7 lines, 512 bytes; sha256 37251821de2ef66349a5219f804dcacdbc7d6f8ede4cff9b759606803f22b084): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S020 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "The DOJ framework recommends consulting counsel before any testing begins."
