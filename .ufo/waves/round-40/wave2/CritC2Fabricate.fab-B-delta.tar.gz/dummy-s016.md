source: S016 — https://www.anthropic.com/coordinated-vulnerability-disclosure — capture corpus/source-snapshots/round-40/S016.txt (7 lines, 526 bytes; sha256 d17579b112fb6b7d1fb2fb5f8c59c03d8648bac160a8974a9d24201d2ad691fd): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S016 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "Anthropic coordinates AI-discovered vulnerabilities through a dedicated intake workflow."
