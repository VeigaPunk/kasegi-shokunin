source: S017 — https://projectzero.google/2025/07/reporting-transparency.html — capture corpus/source-snapshots/round-40/S017.txt (7 lines, 504 bytes; sha256 20d25c44a6b4c290ac097bc142c27079e148e2dacac9facb8e66ad417a98f47c): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S017 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "Project Zero publishes its disclosure timeline data every quarter."
