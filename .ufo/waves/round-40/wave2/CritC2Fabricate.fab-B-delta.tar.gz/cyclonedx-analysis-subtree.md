source: S060 — https://cyclonedx.org/docs/1.7/json/ — capture corpus/source-snapshots/round-40/S060.txt (7 lines, 512 bytes; sha256 a67f87f3f586b8e6fef2a588d10db3a88c7da9b20252563a554accff46c643ec): the quoted sentence appears in the capture; locator L5

recheck: python3 corpus/instruments/source-recheck.py --manifest corpus/source-snapshots/round-40/manifest.json --source S060

# Fabricated F23 entry (CycloneDX analysis subtree).
This entry registers S060 as its single declared source and rechecks it against the
round-40 manifest; the pinned quote is cited from the capture below.
