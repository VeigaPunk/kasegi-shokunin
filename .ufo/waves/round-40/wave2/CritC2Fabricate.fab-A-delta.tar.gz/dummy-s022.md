source: S022 — https://www.cve.org/Resources/Roles/Cnas/CNA_Rules_v4.1.0.pdf — capture corpus/source-snapshots/round-40/S022.txt (7 lines, 498 bytes; sha256 9d232c4d3e9107fb710097ba08cc47228e83a47bb22cc95e9817f1e60d97832d): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S022 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "CNA rules require all assignees to complete annual training."
