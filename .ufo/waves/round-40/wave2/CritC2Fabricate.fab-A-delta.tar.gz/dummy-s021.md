source: S021 — https://www.cisa.gov/news-events/directives/bod-20-01-develop-and-publish-vulnerability-disclosure-policy — capture corpus/source-snapshots/round-40/S021.txt (7 lines, 502 bytes; sha256 22cfbd333c840ff9df8e07095646cb8e474d23556e64576721805594f80ee3c6): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S021 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "BOD 20-01 requires agencies to publish their VDP scope annually."
