source: S025 — https://arxiv.org/abs/2503.17332 — capture corpus/source-snapshots/round-40/S025.txt (7 lines, 507 bytes; sha256 ea697969fdd283bcc3499ea9237767dbddf9e7fa92dc4ac4518eca25bc168b29): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S025 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "CVE-Bench covers over two hundred real-world web application targets."
