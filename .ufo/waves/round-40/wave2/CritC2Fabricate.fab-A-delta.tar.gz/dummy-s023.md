source: S023 — https://www.cisa.gov/resources-tools/programs/coordinated-vulnerability-disclosure-cvd-program — capture corpus/source-snapshots/round-40/S023.txt (7 lines, 510 bytes; sha256 4352ac40242fcd8a7ae28c04ea09eaa5009e7770f4d97eae40aaa87989e793aa): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S023 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "CISA triages reports by impact and likelihood within five business days."
