source: S024 — https://eur-lex.europa.eu/eli/reg/2024/2847/oj/eng — capture corpus/source-snapshots/round-40/S024.txt (7 lines, 526 bytes; sha256 25ac32dffbeb5487d987557258707932b282b52043b2dfe71faa57fd01f9b3ff): the quoted sentence appears in the capture; locator L5

# Dummy mined entry for S024 (fabricated fixture).

The registry row's anchor cell says the page contains the sentence below. The sentence
is pinned in the round-40 manifest and recheckable via source-recheck.py. This entry
records no live fetch; everything here is self-consistent fixture content.

> "The Cyber Resilience Act mandates vulnerability handling timelines per product category."
